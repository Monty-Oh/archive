drop table ganreNum;


create table ganreNum	(
	ganreName	varchar(30),
	ganrenumber	int primary key
);


insert into ganreNum	values('Rock',1);	
insert into ganreNum	values('Ballade',2);	
insert into ganreNum	values('Hiphop',3);	
insert into ganreNum	values('K-pop',4);
insert into ganreNum	values('J-pop',5);




	