drop table like_table;

CREATE TABLE like_table(
	id VARCHAR(20),
	text_number INT,
	genre VARCHAR(10),
	PRIMARY KEY (id, text_number)
);

insert into like_table values('a2175', '1', 'Rock');
insert into like_table values('a2175', '2', 'Rock');
insert into like_table values('a2175', '3', 'Rock');
insert into like_table values('a2175', '4', 'Rock');
insert into like_table values('a2175', '5', 'pop');
insert into like_table values('a2175', '6', 'pop');
insert into like_table values('a2175', '7', 'pop');
insert into like_table values('a2175', '8', 'hip');
insert into like_table values('a2175', '9', 'hip');
insert into like_table values('a2175', '10', 'R&B');
insert into like_table values('a2175', '11', 'R&B');
insert into like_table values('a2175', '12', 'R&B');
insert into like_table values('a2175', '13', 'R&B');
insert into like_table values('a2175', '14', 'R&B');
					